package com.registrationpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationPageUsingReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationPageUsingReactApplication.class, args);
	}

}
